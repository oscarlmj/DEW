let i;
let n=1;
let s="Hola";
let b=true;

alert(typeof(i));
alert(typeof(n));
alert(typeof(s));
alert(typeof(b));