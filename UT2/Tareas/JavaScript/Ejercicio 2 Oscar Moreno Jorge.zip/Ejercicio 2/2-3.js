let i=parseInt(prompt("Introduzca un número:"));
let j=parseInt(prompt("Introduzca otro número:"))

if(i==j)
alert(i+" es igual que "+j);
else if(i>j)
alert(i+" es mayor que "+j);
else 
alert (i+" es menor que "+j);