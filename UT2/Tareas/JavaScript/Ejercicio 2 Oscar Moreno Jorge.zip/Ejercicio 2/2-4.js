let s=prompt("Introduzca un mensaje:")

if(s.length>0)
alert(s);
else
alert("Hola");