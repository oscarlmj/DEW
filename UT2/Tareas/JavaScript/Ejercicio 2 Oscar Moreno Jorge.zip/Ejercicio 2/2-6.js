for(let i=1;i<7;i++)
{
    document.write('<h' + i + '>Encabezado de nivel ' + i + '</h' + i + '>');
}