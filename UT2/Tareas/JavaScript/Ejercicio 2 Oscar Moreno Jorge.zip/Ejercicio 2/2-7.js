let i=1;

while(i<=6)
{
    document.write('<h' + i + '>Encabezado de nivel ' + i + '</h' + i + '>');
    i++;
}