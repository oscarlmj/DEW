let i=parseInt(prompt("Introduce un numero:"));

alert("Cuenta atrás regresiva");
for(let j=i;j>=0;j--)
{
    alert(j);
}

alert("Cuenta atrás progresiva");
for(let x=0;x<=i;x++)
{
    alert(x);
}