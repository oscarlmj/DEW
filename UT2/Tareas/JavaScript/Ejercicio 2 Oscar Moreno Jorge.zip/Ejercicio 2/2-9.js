let i=parseInt(prompt("Introduce un numero:"));
let j=i;
let x=0;

alert("Cuenta atras regresiva");
while(j>=0)
{
    alert(j);
    j--;
}

alert("Cuenta atrás progresiva");
while(x<=i)
{
    alert(x);
    x++;
}