let i="Hola";
let j="Mi nombre es Oscar";

alert(i+j);