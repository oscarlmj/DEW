function saludo(){
    let name=document.getElementById("fname").value;
    let resultado=("Hola de nuevo "+name);
    document.getElementById("imprimirSaludo").innerHTML=resultado;
}

