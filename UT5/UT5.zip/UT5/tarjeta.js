const objeto= {
    "visa": /^4[0-9]{3}-?[0-9]{4}-?[0-9]{4}-?[0-9]{4}$/,
    "mastercard": /^5[1-5][0-9]{2}-?[0-9]{4}-?[0-9]{4}-?[0-9]{4}$/,
    "amex": /^3[47][0-9-]{16}$/,
    "cabal": /^604[23][0-9]{2}$/,
    "naranja": /^(589562|402917|402918|527571|527572|0377798|0377799)[0-9]*$/
}

//Numeros
//Amex 341111212121212121

let cvv=document.getElementById("cvv");

function validarNumero(){
    document.getElementById("carderror").innerHTML="";
    let tarjeta=document.getElementById("card").value;    
    let cvv=document.getElementById("cvv");
    let valida=false;

    try {
        if(tarjeta!== "")
        {

            for(let card in objeto)
            {   
                let tipo=objeto[card];

                if(tipo.test(tarjeta))
                {
                    valida=true;
                    console.log("Esta tarjeta es una "+card);
                    document.getElementById(card).checked=true;

                    try {
                        if(cvv!="")
                        {
                            if(card==="amex")
                            {
                                cvv.placeholder="XXXX";
                                validarCVV();
                            }
                            else
                            {
                                cvv.placeholder="XXX";
                                validarCVV();
                            }
                        }
                        else
                        throw new Error("Este campo es obligatorio");
                    } catch (error) {
                        document.getElementById("cvverror").innerHTML=error.message;
                    }

                }
            }

            if(valida==false)
            throw new Error("Ese número de tarjeta no es valido");

        }
        else throw new Error("Por favor introduce un número de tarjeta");
    } catch (error) {
        document.getElementById("carderror").innerHTML+=error.message;
    }
}

function validarCVV() {
    let cvvInput = document.getElementById("cvv");
    let cvvLength = cvvInput.value.length;
    let cvvPlaceholderLength = cvvInput.placeholder.length;
    document.getElementById("cvverror").innerHTML="";

    try {
        if(cvvInput.value!="")
        {
            if (cvvLength !== cvvPlaceholderLength) {
                throw new Error("Introduce un CVV correcto");
            }
            else
            console.log("CVV correcto");
        }
        else
        throw new Error("Este campo es obligatorio");
    } catch (error) {
        document.getElementById("cvverror").innerHTML+=error.message;
    }
}
